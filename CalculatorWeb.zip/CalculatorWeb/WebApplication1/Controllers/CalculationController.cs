﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Sevices;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class CalculationController : Controller
    {
        private readonly ICalculationService _calcService;

        public CalculationController(ICalculationService calcService)
        {
            _calcService = calcService;
        }

        public IActionResult Index()
        {
            Random random = new Random();
            int a = random.Next(0, 11);
            int b = random.Next(0, 11);

            var model = new CalculationViewModel
            {
                Number1 = a,
                Number2 = b,
                Sum = _calcService.Add(a, b),
                Difference = _calcService.Subtract(a, b),
                Product = _calcService.Multiply(a, b),
                DivisionResult = _calcService.Divide(a, b, out string errorMessage),
                DivisionErrorMessage = errorMessage
            };

            //ViewBag
            ViewBag.Message = "Welcome to Calc Service!";

            return View(model);
        }
    }
}
