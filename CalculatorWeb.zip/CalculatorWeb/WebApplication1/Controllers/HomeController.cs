using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplication1.Models;
using WebApplication1.Sevices;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private readonly Random _random = new Random();
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult ModelCalc()
        {
            int number1 = _random.Next(0, 11);
            int number2 = _random.Next(0, 11);
            var model = new CalculationViewModel
            {
                Number1 = number1,
                Number2 = number2,
                Sum = number1 + number2,
                Difference = number1 - number2,
                Product = number1 * number2,
                DivisionResult = number2 != 0 ? number1 / number2 : 0,
                DivisionErrorMessage = number2 == 0 ? "Div on zero!" : null
            };
            return View(model);
        }

        public IActionResult ViewDataCalc()
        {
            int number1 = _random.Next(0, 11);
            int number2 = _random.Next(0, 11);

            ViewData["Number1"] = number1;
            ViewData["Number2"] = number2;
            ViewData["Sum"] = number1 + number2;
            ViewData["Difference"] = number1 - number2;
            ViewData["Product"] = number1 * number2;
            if (number2 != 0)
            {
                ViewData["DivisionResult"] = (double)number1 / number2;
                ViewData["DivisionErrorMessage"] = null;
            }
            else
            {
                ViewData["DivisionResult"] = null;
                ViewData["DivisionErrorMessage"] = "Div on zero!";
            }

            return View();
        }

       public IActionResult ViewBagCalc()
{
    Random random = new Random();
    int number1 = random.Next(0, 11);
    int number2 = random.Next(0, 11);

    ViewBag.Number1 = number1;
    ViewBag.Number2 = number2;
    ViewBag.Sum = number1 + number2;
    ViewBag.Difference = number1 - number2;
    ViewBag.Product = number1 * number2;

    if (number2 != 0)
    {
        ViewBag.DivisionResult = (double)number1 / number2;
        ViewBag.DivisionErrorMessage = null; 
    }
    else
    {
        ViewBag.DivisionResult = null; 
        ViewBag.DivisionErrorMessage = "I can't div on zero!"; 
    }

    return View(); 
}
        public IActionResult ServiceInjectionCalc([FromServices] ICalculationService calcService)
        {
            int number1 = _random.Next(0, 11);
            int number2 = _random.Next(0, 11);

            var model = new CalculationViewModel
            {
                Number1 = number1,
                Number2 = number2,
                Sum = calcService.Add(number1, number2),
                Difference = calcService.Subtract(number1, number2),
                Product = calcService.Multiply(number1, number2),
                DivisionResult = calcService.Divide(number1, number2, out string errorMessage),
                DivisionErrorMessage = errorMessage
            };

            return View(model);
        }
    }
}
