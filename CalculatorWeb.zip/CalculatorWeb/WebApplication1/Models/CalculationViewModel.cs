﻿namespace WebApplication1.Models
{
    public class CalculationViewModel
    {
        public int Number1 { get; set; }
        public int Number2 { get; set; }
        public int Sum { get; set; }
        public int Difference { get; set; }
        public int Product { get; set; }
        public double DivisionResult { get; set; }
        public string ? DivisionErrorMessage { get; set; }
    }
}
