using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Views.Home
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
