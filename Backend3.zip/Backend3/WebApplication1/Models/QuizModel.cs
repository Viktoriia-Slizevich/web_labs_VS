namespace WebApplication1.Models
{
    public record QuizModel(Quiz quiz);
}