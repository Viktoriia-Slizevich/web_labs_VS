using WebApplication1.Models;

namespace WebApplication1.Services
{
    public interface IQuizService
    {
        public Quiz getCurrentQuiz();
        public QuizQuestion addNewQuestion(Quiz quiz);
        public QuizQuestion getCurrentQuestion(Quiz quiz);
        public void answerLastQuestion(QuizAnswer answer, Quiz quiz);
        public void finish(Quiz quiz);
    }
}