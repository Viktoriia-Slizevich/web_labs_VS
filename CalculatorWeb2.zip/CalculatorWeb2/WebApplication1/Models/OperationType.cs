using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public enum OperationType
    {
        [Display(Name = "+")]
        Add,
        [Display(Name = "-")]
        Subtract,
        [Display(Name = "*")]
        Multiply,
        [Display(Name = "/")]
        Divide
    }
}
